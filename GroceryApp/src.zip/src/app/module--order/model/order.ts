export class Order{
    orderId:number;
    name:string;
    address:string;
    amount:number;
    paymentMethod:string;
    status:string;
    time:Date;

}