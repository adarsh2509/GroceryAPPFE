export class Buyer{

    buyerId:number;
    name:String;
    phNo:String;
    address:String;
    emailId:String;
    pincode:number;
}