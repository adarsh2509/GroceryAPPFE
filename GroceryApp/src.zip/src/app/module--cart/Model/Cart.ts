export class Cart{
    cartId: number;
    groceryName: string;
    groceryType: string;
    groceryPrice: number;
    image: string;
    description: string;
    quantity: string;
    num:number;
}