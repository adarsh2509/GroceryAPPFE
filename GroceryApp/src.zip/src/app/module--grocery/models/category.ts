export class Category{
    categoryId!:number;
    categoryName!:string;
    image!:string
  groceries: import("c:/Users/237411/Desktop/project/GroceryApp/src/app/module--grocery/models/grocery").Grocery[];
}